﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vintage.Data
{
    public class HoaDon
    {
        public int ID { get; set; }
        public DateTime NgayLap { get; set; }

        public int NhanVienID { get; set; }
        public int KhachHangID { get; set; }

        public int TongTien { get; set; }

        public virtual NhanVien NhanVien { get; set; } = null!;
        public virtual KhachHang KhachHang { get; set; } = null!;

        public virtual ObservableCollection<HoaDon_ChiTiet> HoaDon_ChiTiet { get; set; } = new();
    }
}
