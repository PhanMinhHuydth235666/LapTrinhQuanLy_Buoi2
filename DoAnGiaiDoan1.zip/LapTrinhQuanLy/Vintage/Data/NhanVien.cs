﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vintage.Data
{
    public class NhanVien
    {
        public int ID { get; set; }
        public string TenNhanVien { get; set; }
        public string DienThoai { get; set; }
        public string ChucVu { get; set; }
        public DateTime NgayVaoLam { get; set; }

        public virtual ObservableCollection<HoaDon> HoaDon { get; set; } = new();
    }
}
