﻿CREATE DATABASE QLVintageShop;
GO

USE QLVintageShop;
GO

CREATE TABLE LoaiSanPham
(
    ID INT IDENTITY(1,1) PRIMARY KEY,
    TenLoai NVARCHAR(100) NOT NULL
);

CREATE TABLE NhanVien
(
    ID INT IDENTITY(1,1) PRIMARY KEY,
    TenNhanVien NVARCHAR(150) NOT NULL,
    DienThoai NVARCHAR(20),
    ChucVu NVARCHAR(100),
    NgayVaoLam DATE NOT NULL
);

CREATE TABLE KhachHang
(
    ID INT IDENTITY(1,1) PRIMARY KEY,
    TenKhachHang NVARCHAR(150) NOT NULL,
    DienThoai NVARCHAR(20),
    DiemTichLuy INT DEFAULT 0
);

CREATE TABLE SanPham
(
    ID INT IDENTITY(1,1) PRIMARY KEY,
    LoaiSanPhamID INT NOT NULL,
    TenSanPham NVARCHAR(200) NOT NULL,
    Size NVARCHAR(20),
    DonGia INT NOT NULL CHECK (DonGia >= 0),
    SoLuong INT NOT NULL CHECK (SoLuong >= 0),
    HinhAnh NVARCHAR(255),

    CONSTRAINT FK_SanPham_LoaiSanPham
        FOREIGN KEY (LoaiSanPhamID)
        REFERENCES LoaiSanPham(ID)
);

CREATE TABLE HoaDon
(
    ID INT IDENTITY(1,1) PRIMARY KEY,
    NgayLap DATETIME DEFAULT GETDATE(),
    NhanVienID INT NOT NULL,
    KhachHangID INT NOT NULL,
    TongTien INT DEFAULT 0,

    CONSTRAINT FK_HoaDon_NhanVien
        FOREIGN KEY (NhanVienID)
        REFERENCES NhanVien(ID),

    CONSTRAINT FK_HoaDon_KhachHang
        FOREIGN KEY (KhachHangID)
        REFERENCES KhachHang(ID)
);

CREATE TABLE HoaDon_ChiTiet
(
    ID INT IDENTITY(1,1) PRIMARY KEY,
    HoaDonID INT NOT NULL,
    SanPhamID INT NOT NULL,
    SoLuong INT NOT NULL,
    DonGia INT NOT NULL,
    ThanhTien INT NOT NULL,

    CONSTRAINT FK_CTHD_HoaDon
        FOREIGN KEY (HoaDonID)
        REFERENCES HoaDon(ID)
        ON DELETE CASCADE,

    CONSTRAINT FK_CTHD_SanPham
        FOREIGN KEY (SanPhamID)
        REFERENCES SanPham(ID)
);

-- LoaiSanPham
INSERT INTO LoaiSanPham (TenLoai) VALUES
(N'Jacket'),
(N'Sweater'),
(N'Flannel'),
(N'Vintage Tee'),
(N'Denim');

-- NhanVien
INSERT INTO NhanVien (TenNhanVien, DienThoai, ChucVu, NgayVaoLam) VALUES
(N'Nguyễn Minh Anh', '0901234567', N'Quản lý', '2022-05-10'),
(N'Trần Hoàng Nam', '0912345678', N'Nhân viên bán hàng', '2023-03-15');

-- KhachHang
INSERT INTO KhachHang (TenKhachHang, DienThoai, DiemTichLuy) VALUES
(N'Lê Thu Hà', '0987654321', 120),
(N'Phạm Gia Huy', '0978123456', 50);

-- SanPham (bây giờ LoaiSanPham đã có ID 1-5 nên không lỗi)
INSERT INTO SanPham (LoaiSanPhamID, TenSanPham, Size, DonGia, SoLuong, HinhAnh) VALUES
(1, N'Vintage Leather Jacket 90s', N'L', 850000, 5, N'jacket1.jpg'),
(1, N'Bomber Jacket Retro', N'M', 650000, 8, N'jacket2.jpg'),
(2, N'Oversized Sweater 80s', N'XL', 420000, 10, N'sweater1.jpg'),
(3, N'Red Flannel Shirt', N'M', 350000, 7, N'flannel1.jpg'),
(4, N'Graphic Vintage Tee', N'L', 280000, 15, N'tee1.jpg'),
(5, N'Denim Jacket Washed Blue', N'L', 720000, 6, N'denim1.jpg');

-- HoaDon
INSERT INTO HoaDon (NhanVienID, KhachHangID, TongTien)
VALUES (1, 1, 1130000);

-- HoaDon_ChiTiet
INSERT INTO HoaDon_ChiTiet (HoaDonID, SanPhamID, SoLuong, DonGia, ThanhTien)
VALUES
(1, 1, 1, 850000, 850000),
(1, 4, 1, 280000, 280000);

select * from HoaDon_ChiTiet